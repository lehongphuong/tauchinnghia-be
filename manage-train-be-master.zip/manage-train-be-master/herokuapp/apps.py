from django.apps import AppConfig


class HerokuappConfig(AppConfig):
    name = 'herokuapp'
